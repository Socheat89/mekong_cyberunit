<?php
// public/admin/approve_payment.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$ref = $_GET['ref'] ?? '';

if (empty($ref)) {
    die("Error: No reference ID provided.");
}

$logFile = __DIR__ . '/../../logs/transactions.json';

if (!file_exists($logFile)) {
    die("Error: Transaction log not found.");
}

$transactions = json_decode(file_get_contents($logFile), true) ?? [];

if (!isset($transactions[$ref])) {
    die("Error: Transaction not found.");
}

// Update Status
$transactions[$ref]['status'] = 'APPROVED';
$transactions[$ref]['approved_at'] = time();

if (file_put_contents($logFile, json_encode($transactions, JSON_PRETTY_PRINT))) {
    // Show success page
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Payment Approved</title>
        <style>
            body { font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; background: #f0fdf4; margin: 0; }
            .card { background: white; padding: 2rem; border-radius: 1rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); text-align: center; max-width: 400px; }
            .icon { font-size: 3rem; color: #16a34a; margin-bottom: 1rem; }
            h1 { color: #166534; margin: 0 0 0.5rem 0; }
            p { color: #4b5563; }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="icon">✅</div>
            <h1>Payment Approved</h1>
            <p>Transaction <strong><?php echo htmlspecialchars(substr($ref, 0, 8)); ?>...</strong> has been marked as successful.</p>
            <p>The user's page will update automatically.</p>
        </div>
    </body>
    </html>
    <?php
} else {
    echo "Error: Failed to save status.";
}
?>
